﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace _13collect
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                ArrayList list = new ArrayList();
                ArrayList list2 = new ArrayList();
                list.Add(4.5);
                list.Add(18);
                list.AddRange(new string[] { "Студент", "Петров" });
                Console.Write("Сколько строк вы будете записывать в коллекцию?: ");
                int count = int.Parse(Console.ReadLine());
                Console.Write("Введите индекс, после которого будет вставлена коллекция: ");
                int n1 = int.Parse(Console.ReadLine());
                Console.Write("Введите количество К элементов, которые будут удалены из коллекции: ");
                int K = int.Parse(Console.ReadLine());
                if (count > 0 && n1 > 0 && K > 0)
                {
                    for (int i = 0; i < count; i++)
                    {
                        Console.Write("Введите {0} строку: ", i + 1);
                        list2.Add(Console.ReadLine());
                    }
                    Console.WriteLine("Старый список:");
                    foreach (object e in list)
                    {
                        Console.WriteLine(e);
                    }
                    Console.WriteLine("Новый список: ");
                    list.InsertRange(n1, list2);
                    for (int i = 0; i < list.Count; i++)
                    {
                        Console.WriteLine(list[i]);
                    }
                    Console.Write("После какого элемента будет производится удаление?: ");
                    int delete = int.Parse(Console.ReadLine());
                    if (list.Count - delete - K >= 0)
                    {
                        list.RemoveRange(delete, K);
                        Console.WriteLine("Измененный список:");
                        for (int i = 0; i < list.Count; i++)
                        {
                            Console.WriteLine(list[i]);
                        }
                    }
                    else Console.WriteLine("Не могу удалить так много элементов, так как в коллекции их меньше");
                }
                else Console.WriteLine("Была попытка ввода отрицательного значения");
            }
            catch { Console.WriteLine("Некорректный ввод данных!"); }
            Console.ReadKey();


        }
    }
}
